# DZI Project Flow – Ultimate Package
Includes: Hosting configs, Firestore/Storage rules, role dashboards, real-time Projects & Queries, Documents uploads, Attendance, Email+FCM notifications, thumbnails, signed URLs, CI/CD, and **Phone (OTP) login**.
## Quick Start
1. npm i
2. Copy `.env.example` → `.env` and fill Firebase config + `VITE_FIREBASE_VAPID_KEY`.
3. Firebase Console → Auth → enable Email/Password (optional) and **Phone** provider.
4. Build & Deploy
```
npm run build
npx firebase use dzi-project-flow   # or your project id
npx firebase deploy --only hosting,firestore,storage,functions
```
## OTP Login
- Route: `/phone-login`. Uses Invisible reCAPTCHA.
- Authorized domains must include your site.
- Creates/merges profile at `users/{uid}`.
## Notifications
- Configure SMTP:
```
firebase functions:config:set   smtp.host="smtp.gmail.com" smtp.port="587"   smtp.user="YOUR_SMTP_USER" smtp.pass="YOUR_SMTP_PASS"   mail.from="DZI Support <no-reply@decorzoneinteriors.com>"   mail.to="pm@decorzoneinteriors.com"
```
- Web Push: set `VITE_FIREBASE_VAPID_KEY` then rebuild.
## CI/CD
- `.github/workflows/firebase-hosting.yml`. Add repo secrets: `FIREBASE_SERVICE_ACCOUNT`, `FIREBASE_PROJECT_ID`.
---
Generated 2025-08-27T18:46:11