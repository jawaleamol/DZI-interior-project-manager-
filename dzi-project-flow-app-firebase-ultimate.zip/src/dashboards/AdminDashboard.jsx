import React from 'react'
import Projects from '../modules/Projects'
import Queries from '../modules/Queries'
import Documents from '../modules/Documents'
export default function AdminDashboard(){ return (<div className='space-y-6'><h1 className='text-2xl font-bold'>Admin Dashboard</h1><Projects/><Queries/><Documents/></div>) }