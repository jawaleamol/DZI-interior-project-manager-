import React from 'react'
import Queries from '../modules/Queries'
import Attendance from '../modules/Attendance'
export default function AgencyDashboard(){ return (<div className='space-y-6'><h1 className='text-2xl font-bold'>Agency Portal</h1><Attendance/><Queries/></div>) }