import React from 'react'
import Projects from '../modules/Projects'
import Queries from '../modules/Queries'
export default function PMDashboard(){ return (<div className='space-y-6'><h1 className='text-2xl font-bold'>Project Manager Dashboard</h1><Projects/><Queries/></div>) }