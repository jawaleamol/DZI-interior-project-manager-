import React from 'react'
import Projects from '../modules/Projects'
import Documents from '../modules/Documents'
export default function CustomerDashboard(){ return (<div className='space-y-6'><h1 className='text-2xl font-bold'>Customer Portal</h1><Projects/><Documents/></div>) }