import React,{createContext,useContext,useEffect,useState} from 'react'
import { auth } from '../lib/firebase'
import { onAuthStateChanged, getIdTokenResult } from 'firebase/auth'
const C=createContext(null)
export const AuthProvider=({children})=>{ const [user,setUser]=useState(null); const[claims,setClaims]=useState(null); const[loading,setLoading]=useState(true);
useEffect(()=> onAuthStateChanged(auth,async(u)=>{ setUser(u); if(u){ try{ const t=await getIdTokenResult(u,true); setClaims(t.claims||{}) }catch{ setClaims({}) } } else setClaims(null); setLoading(false) }),[]);
return <C.Provider value={{user,claims,loading}}>{children}</C.Provider> }
export const useAuth=()=>useContext(C)