import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import "./index.css";
import Attendance from "./modules/attendance/Attendance";

const Login = () => (
  <div className="min-h-screen flex items-center justify-center bg-dzi-bg">
    <div className="bg-white shadow-md p-6 rounded w-full max-w-sm">
      <h2 className="text-2xl font-semibold text-dzi-primary mb-4">Login</h2>
      <input type="email" placeholder="Email" className="w-full p-2 mb-3 border rounded" />
      <input type="password" placeholder="Password" className="w-full p-2 mb-3 border rounded" />
      <button className="bg-dzi-accent text-white w-full py-2 rounded">Log In</button>
    </div>
  </div>
);

const Dashboard = () => (
  <div className="min-h-screen bg-dzi-bg text-dzi-text">
    <header className="bg-dzi-primary text-white p-4 shadow-md">
      <h1 className="text-xl font-semibold">DZI - Project Flow Dashboard</h1>
    </header>
    <main className="p-4">
      <p>Welcome to your interior project dashboard.</p>
    </main>
  </div>
);

const App = () => {
  const isAuthenticated = false; // Replace with Firebase auth state logic

  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/attendance" element={<Attendance />} />
        <Route path="/dashboard" element={isAuthenticated ? <Dashboard /> : <Navigate to="/login" />} />
        <Route path="*" element={<Navigate to="/login" />} />
      </Routes>
    </Router>
  );
};

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
