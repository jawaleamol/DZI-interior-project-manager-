import React,{useState} from 'react'
import { signInWithEmailAndPassword } from 'firebase/auth'
import { auth } from '../lib/firebase'; import { useNavigate, Link } from 'react-router-dom'
export default function Login(){ const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [err,setErr]=useState(''); const nav=useNavigate();
const onSubmit=async(e)=>{e.preventDefault(); setErr(''); try{ await signInWithEmailAndPassword(auth,email,password); nav('/') }catch(e){ setErr(e.message) } }
return (<div className='max-w-md mx-auto mt-16 card'><h1 className='text-xl font-bold mb-4'>Email Login</h1><form onSubmit={onSubmit} className='space-y-3'>
<input className='w-full border rounded px-3 py-2' placeholder='Email' value={email} onChange={e=>setEmail(e.target.value)}/>
<input className='w-full border rounded px-3 py-2' type='password' placeholder='Password' value={password} onChange={e=>setPassword(e.target.value)}/>
{err&&<div className='text-red-600 text-sm'>{err}</div>}<button className='btn btn-primary w-full'>Sign in</button></form><div className='text-sm mt-2'>Prefer mobile? <Link to='/phone-login' className='text-blue-600 underline'>Login with OTP</Link></div></div>) }