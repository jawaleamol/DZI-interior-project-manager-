import React from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import Navbar from './components/Navbar'
import ProtectedRoute from './components/ProtectedRoute'
import RoleGuard from './components/RoleGuard'
import { AuthProvider } from './context/AuthContext'
import Login from './pages/Login'
import PhoneLogin from './pages/PhoneLogin'
import FCMInit from './components/FCMInit'
import AdminDashboard from './dashboards/AdminDashboard'
import PMDashboard from './dashboards/PMDashboard'
import CustomerDashboard from './dashboards/CustomerDashboard'
import AgencyDashboard from './dashboards/AgencyDashboard'
function Home(){ return (<div className='p-4 max-w-6xl mx-auto space-y-4'><div className='card'><div className='font-bold text-xl mb-2'>Welcome to DZI Project Flow</div><p className='text-gray-600'>Choose a portal or sign in:</p><div className='mt-4 flex flex-wrap gap-2'><Link className='btn' to='/admin'>Admin</Link><Link className='btn' to='/pm'>Project Manager</Link><Link className='btn' to='/customer'>Customer</Link><Link className='btn' to='/agency'>Agency</Link></div></div></div>) }
export default function App(){ return (<AuthProvider><Navbar/><FCMInit/><Routes>
<Route path='/login' element={<Login/>}/>
<Route path='/phone-login' element={<PhoneLogin/>}/>
<Route path='/' element={<ProtectedRoute><Home/></ProtectedRoute>}/>
<Route path='/admin' element={<ProtectedRoute><RoleGuard allow={['admin']}><div className='p-4 max-w-6xl mx-auto'><AdminDashboard/></div></RoleGuard></ProtectedRoute>}/>
<Route path='/pm' element={<ProtectedRoute><RoleGuard allow={['projectManager','admin']}><div className='p-4 max-w-6xl mx-auto'><PMDashboard/></div></RoleGuard></ProtectedRoute>}/>
<Route path='/customer' element={<ProtectedRoute><RoleGuard allow={['customer','admin']}><div className='p-4 max-w-6xl mx-auto'><CustomerDashboard/></div></RoleGuard></ProtectedRoute>}/>
<Route path='/agency' element={<ProtectedRoute><RoleGuard allow={['agency','admin']}><div className='p-4 max-w-6xl mx-auto'><AgencyDashboard/></div></RoleGuard></ProtectedRoute>}/>
</Routes></AuthProvider>) }