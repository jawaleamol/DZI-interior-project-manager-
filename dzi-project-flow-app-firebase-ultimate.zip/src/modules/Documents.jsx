import React from 'react'
import Uploader from '../components/Uploader'
export default function Documents(){ return (<div className='space-y-4'><Uploader path='documents'/><p className='text-sm text-gray-600'>Uploaded files save metadata to Firestore collection <code>files</code>.</p></div>) }