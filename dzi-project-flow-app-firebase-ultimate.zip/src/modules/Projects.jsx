import React,{useEffect,useState} from 'react'
import { collection,onSnapshot,query,orderBy,addDoc,serverTimestamp } from 'firebase/firestore'
import { db } from '../lib/firebase'
export default function Projects(){ const [items,setItems]=useState([]); const [name,setName]=useState('');
useEffect(()=>{ const q=query(collection(db,'projects'),orderBy('createdAt','desc')); return onSnapshot(q,s=> setItems(s.docs.map(d=>({id:d.id,...d.data()})))) },[])
const add=async(e)=>{ e.preventDefault(); if(!name) return; await addDoc(collection(db,'projects'),{name,status:'new',createdAt:serverTimestamp()}); setName('') }
return (<div className='space-y-4'><form onSubmit={add} className='card flex gap-2'><input className='border rounded px-3 py-2 flex-1' placeholder='New project name' value={name} onChange={e=>setName(e.target.value)}/><button className='btn btn-primary'>Add</button></form>
<div className='grid md:grid-cols-2 gap-3'>{items.map(p=>(<div key={p.id} className='card'><div className='font-semibold'>{p.name}</div><div className='text-sm text-gray-500'>Status: {p.status||'—'}</div></div>))}</div></div>) }