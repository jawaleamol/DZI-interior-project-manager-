import React,{useEffect,useState} from 'react'
import { collection,onSnapshot,addDoc,serverTimestamp,orderBy,query } from 'firebase/firestore'
import { db } from '../lib/firebase'
export default function Queries(){ const [items,setItems]=useState([]); const [text,setText]=useState('');
useEffect(()=>{ const q=query(collection(db,'queries'),orderBy('createdAt','desc')); return onSnapshot(q,s=> setItems(s.docs.map(d=>({id:d.id,...d.data()})))) },[])
const add=async(e)=>{ e.preventDefault(); if(!text) return; await addDoc(collection(db,'queries'),{ text, createdAt:serverTimestamp() }); setText('') }
return (<div className='space-y-4'><form onSubmit={add} className='card flex gap-2'><input className='border rounded px-3 py-2 flex-1' placeholder='Type a query / issue' value={text} onChange={e=>setText(e.target.value)}/><button className='btn btn-primary'>Add</button></form>
<div className='space-y-2'>{items.map(q=>(<div key={q.id} className='card'><div className='font-medium'>{q.text}</div></div>))}</div></div>) }