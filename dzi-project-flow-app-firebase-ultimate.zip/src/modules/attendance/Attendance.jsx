

import { initializeApp } from "firebase/app";
import { getStorage, ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { getFirestore, collection, addDoc, serverTimestamp } from "firebase/firestore";

// Your Firebase configuration
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const storage = getStorage(app);
const db = getFirestore(app);

import React, { useState, useEffect } from "react";

const Attendance = () => {
  const [location, setLocation] = useState(null);
  const [image, setImage] = useState(null);

  useEffect(() => {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setLocation({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        });
      },
      (error) => {
        console.error("Error fetching location:", error);
      }
    );
  }, []);

  const handleCapture = (event) => {
    const file = event.target.files[0];
    if (file) {
      setImage(URL.createObjectURL(file));
    }
  };


  const handleSubmit = async () => {
    if (!image || !location) {
      alert("Please allow location and capture your face.");
      return;
    }

    try {
      const blob = await fetch(image).then(r => r.blob());
      const storageRef = ref(storage, `attendance/${Date.now()}.jpg`);
      await uploadBytes(storageRef, blob);
      const imageUrl = await getDownloadURL(storageRef);

      await addDoc(collection(db, "attendance"), {
        imageUrl,
        location,
        timestamp: serverTimestamp(),
      });

      alert("Attendance submitted successfully!");
    } catch (error) {
      console.error("Error submitting attendance:", error);
      alert("Error submitting attendance. Please try again.");
    }
  };

  return (
    <div className="p-4 max-w-md mx-auto bg-white rounded shadow">
      <h2 className="text-lg font-semibold text-dzi-primary mb-4">Employee Face Attendance</h2>
      <input type="file" accept="image/*" capture="user" onChange={handleCapture} className="mb-4" />
      {image && <img src={image} alt="Face Capture" className="rounded mb-4" />}
      <button
        onClick={handleSubmit}
        className="bg-dzi-accent text-white px-4 py-2 rounded"
      >
        Submit Attendance
      </button>
      {location && (
        <p className="text-sm text-dzi-text mt-2">
          Location: {location.lat.toFixed(4)}, {location.lng.toFixed(4)}
        </p>
      )}
    </div>
  );
};

export default Attendance;
