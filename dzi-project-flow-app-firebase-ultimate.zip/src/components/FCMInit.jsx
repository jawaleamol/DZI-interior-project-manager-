import React,{useEffect} from 'react'
import { useAuth } from '../context/AuthContext'
import { ensureFcmToken, db } from '../lib/firebase'
import { doc, setDoc } from 'firebase/firestore'
export default function FCMInit(){ const {user}=useAuth(); useEffect(()=>{ if(!user) return; ensureFcmToken(async(token)=>{ await setDoc(doc(db,'fcmTokens',`${user.uid}__${token.slice(0,16)}`),{uid:user.uid,token,updatedAt:new Date().toISOString()},{merge:true}) }) },[user]); return null }