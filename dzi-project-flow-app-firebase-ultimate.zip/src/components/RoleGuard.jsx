import React from 'react'
import { Navigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
export default function RoleGuard({allow=[],children}){ const {claims,loading}=useAuth(); if(loading) return <div className='p-6'>Loading...</div>; const role=claims?.role; if(!role || (allow.length && !allow.includes(role))) return <Navigate to='/' replace/>; return children }