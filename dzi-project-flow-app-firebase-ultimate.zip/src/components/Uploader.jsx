import React,{useState} from 'react'
import { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage'
import { storage, db } from '../lib/firebase'
import { doc, serverTimestamp, setDoc } from 'firebase/firestore'
export default function Uploader({path='uploads'}){ const [progress,setProgress]=useState(0); const [url,setUrl]=useState(null);
const onFile=(e)=>{ const file=e.target.files?.[0]; if(!file) return; const id=`${Date.now()}-${file.name}`; const r=ref(storage,`${path}/${id}`); const task=uploadBytesResumable(r,file);
task.on('state_changed',s=> setProgress(Math.round(s.bytesTransferred/s.totalBytes*100)),console.error,async()=>{ const downloadURL=await getDownloadURL(task.snapshot.ref); setUrl(downloadURL); await setDoc(doc(db,'files',id),{ path:`${path}/${id}`, name:file.name, size:file.size, url:downloadURL, createdAt:serverTimestamp() }) }) }
return (<div className='card'><div className='font-medium mb-2'>Upload file</div><input type='file' onChange={onFile}/><div className='mt-2 text-sm'>Progress: {progress}%</div>{url&&<a className='text-blue-600 underline' href={url} target='_blank' rel='noreferrer'>Open uploaded file</a>}</div>) }