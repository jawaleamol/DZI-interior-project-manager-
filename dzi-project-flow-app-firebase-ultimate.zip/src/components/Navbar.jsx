import React from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { auth } from '../lib/firebase'
import { signOut } from 'firebase/auth'
export default function Navbar(){ const {user,claims}=useAuth(); return (<nav className='w-full bg-white border-b sticky top-0 z-10'><div className='max-w-6xl mx-auto px-4 py-3 flex items-center justify-between'>
<Link to='/' className='font-bold text-lg'>DZI Project Flow</Link><div className='flex items-center gap-3'>{claims?.role&&<span className='text-sm px-2 py-1 border rounded'>{claims.role}</span>}{user?(<button className='btn btn-primary' onClick={()=>signOut(auth)}>Sign out</button>):(<Link to='/phone-login' className='btn'>Login</Link>)}</div></div></nav>) }